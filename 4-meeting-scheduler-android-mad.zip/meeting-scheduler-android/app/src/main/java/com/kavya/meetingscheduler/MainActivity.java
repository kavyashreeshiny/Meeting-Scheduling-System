package com.kavya.meetingscheduler;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/** Shows all meetings (sorted by date/time). Tap to edit, long-press to delete. */
public class MainActivity extends Activity {

    private DBHelper db;
    private MeetingAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBHelper(this);
        ListView list = findViewById(R.id.listMeetings);
        TextView empty = findViewById(R.id.tvEmpty);
        Button add = findViewById(R.id.btnAdd);

        adapter = new MeetingAdapter(this, new ArrayList<Meeting>());
        list.setAdapter(adapter);
        list.setEmptyView(empty);

        add.setOnClickListener(v -> startActivity(new Intent(this, AddEditMeetingActivity.class)));

        list.setOnItemClickListener((parent, view, position, id) -> {
            Meeting m = adapter.getItem(position);
            Intent i = new Intent(this, AddEditMeetingActivity.class);
            i.putExtra(AddEditMeetingActivity.EXTRA_ID, m.id);
            startActivity(i);
        });

        list.setOnItemLongClickListener((parent, view, position, id) -> {
            final Meeting m = adapter.getItem(position);
            new AlertDialog.Builder(this)
                    .setTitle("Delete meeting?")
                    .setMessage(m.title)
                    .setPositiveButton("Delete", (d, w) -> {
                        db.delete(m.id);
                        refresh();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        adapter.clear();
        adapter.addAll(db.getAll());
        adapter.notifyDataSetChanged();
    }
}
