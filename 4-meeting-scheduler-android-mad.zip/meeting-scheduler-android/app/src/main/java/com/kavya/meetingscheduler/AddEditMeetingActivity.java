package com.kavya.meetingscheduler;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

/** Create a new meeting or edit/delete/share an existing one. */
public class AddEditMeetingActivity extends Activity {

    public static final String EXTRA_ID = "meeting_id";

    private DBHelper db;
    private long meetingId = -1;

    private EditText etTitle, etLocation, etParticipants, etNotes;
    private Button btnDate, btnStart, btnEnd;
    private String date = "", start = "", end = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);
        db = new DBHelper(this);

        etTitle = findViewById(R.id.etTitle);
        etLocation = findViewById(R.id.etLocation);
        etParticipants = findViewById(R.id.etParticipants);
        etNotes = findViewById(R.id.etNotes);
        btnDate = findViewById(R.id.btnDate);
        btnStart = findViewById(R.id.btnStart);
        btnEnd = findViewById(R.id.btnEnd);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnShare = findViewById(R.id.btnShare);
        Button btnDelete = findViewById(R.id.btnDelete);

        meetingId = getIntent().getLongExtra(EXTRA_ID, -1);
        if (meetingId != -1) {
            Meeting m = db.getById(meetingId);
            if (m == null) { finish(); return; }
            setTitle("Edit meeting");
            etTitle.setText(m.title);
            etLocation.setText(m.location);
            etParticipants.setText(m.participants);
            etNotes.setText(m.notes);
            date = m.date;
            start = m.startTime;
            end = m.endTime;
        } else {
            setTitle("New meeting");
            btnShare.setVisibility(View.GONE);
            btnDelete.setVisibility(View.GONE);
        }
        refreshButtons();

        btnDate.setOnClickListener(v -> pickDate());
        btnStart.setOnClickListener(v -> pickTime(true));
        btnEnd.setOnClickListener(v -> pickTime(false));
        btnSave.setOnClickListener(v -> save());
        btnShare.setOnClickListener(v -> share());
        btnDelete.setOnClickListener(v -> confirmDelete());
    }

    private void refreshButtons() {
        btnDate.setText(date.isEmpty() ? "Pick date" : "Date: " + date);
        btnStart.setText(start.isEmpty() ? "Start time" : "Start: " + start);
        btnEnd.setText(end.isEmpty() ? "End time" : "End: " + end);
    }

    private void pickDate() {
        Calendar c = Calendar.getInstance();
        if (!date.isEmpty()) {
            String[] p = date.split("-");
            c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]));
        }
        new DatePickerDialog(this, (view, y, m, d) -> {
            date = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            refreshButtons();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void pickTime(final boolean isStart) {
        String current = isStart ? start : end;
        int h = 9, min = 0;
        if (!current.isEmpty()) {
            String[] p = current.split(":");
            h = Integer.parseInt(p[0]);
            min = Integer.parseInt(p[1]);
        }
        new TimePickerDialog(this, (view, hour, minute) -> {
            String t = String.format(Locale.US, "%02d:%02d", hour, minute);
            if (isStart) start = t; else end = t;
            refreshButtons();
        }, h, min, true).show();
    }

    private void save() {
        String title = etTitle.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        if (title.isEmpty() || location.isEmpty()) {
            toast("Title and location are required");
            return;
        }
        if (date.isEmpty() || start.isEmpty() || end.isEmpty()) {
            toast("Pick the date, start time and end time");
            return;
        }
        if (end.compareTo(start) <= 0) {
            toast("End time must be after start time");
            return;
        }
        if (db.hasConflict(date, location, start, end, meetingId)) {
            toast("That location is already booked for an overlapping time");
            return;
        }
        Meeting m = new Meeting(meetingId, title, date, start, end, location,
                etParticipants.getText().toString().trim(), etNotes.getText().toString().trim());
        if (meetingId == -1) db.insert(m); else db.update(m);
        toast("Meeting saved");
        finish();
    }

    private void share() {
        String text = "Meeting: " + etTitle.getText() + "\n"
                + "When: " + date + ", " + start + " - " + end + "\n"
                + "Where: " + etLocation.getText() + "\n"
                + "Participants: " + etParticipants.getText();
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Meeting invite: " + etTitle.getText());
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, "Share invite via"));
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Delete this meeting?")
                .setPositiveButton("Delete", (d, w) -> {
                    db.delete(meetingId);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
