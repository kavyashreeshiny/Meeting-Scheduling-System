package com.kavya.meetingscheduler;

/** Plain data holder for one meeting. Date is yyyy-MM-dd, times are 24h HH:mm. */
public class Meeting {
    public long id;
    public String title;
    public String date;
    public String startTime;
    public String endTime;
    public String location;
    public String participants;
    public String notes;

    public Meeting() { }

    public Meeting(long id, String title, String date, String startTime, String endTime,
                   String location, String participants, String notes) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.location = location;
        this.participants = participants;
        this.notes = notes;
    }
}
