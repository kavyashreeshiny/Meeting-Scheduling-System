package com.kavya.meetingscheduler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class MeetingAdapter extends ArrayAdapter<Meeting> {

    public MeetingAdapter(Context context, List<Meeting> meetings) {
        super(context, 0, meetings);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        if (row == null) {
            row = LayoutInflater.from(getContext()).inflate(R.layout.item_meeting, parent, false);
        }
        Meeting m = getItem(position);
        ((TextView) row.findViewById(R.id.tvTitle)).setText(m.title);
        ((TextView) row.findViewById(R.id.tvWhen)).setText(m.date + "   " + m.startTime + " - " + m.endTime);
        String who = (m.participants == null || m.participants.trim().isEmpty())
                ? "no participants" : m.participants;
        ((TextView) row.findViewById(R.id.tvWhere)).setText(m.location + "  |  " + who);
        return row;
    }
}
