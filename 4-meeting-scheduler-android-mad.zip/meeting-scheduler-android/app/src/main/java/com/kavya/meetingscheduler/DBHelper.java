package com.kavya.meetingscheduler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** SQLite storage for meetings. */
public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "meetings.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "meetings";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "title TEXT NOT NULL, "
                + "date TEXT NOT NULL, "
                + "start_time TEXT NOT NULL, "
                + "end_time TEXT NOT NULL, "
                + "location TEXT NOT NULL, "
                + "participants TEXT, "
                + "notes TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    private ContentValues toValues(Meeting m) {
        ContentValues v = new ContentValues();
        v.put("title", m.title);
        v.put("date", m.date);
        v.put("start_time", m.startTime);
        v.put("end_time", m.endTime);
        v.put("location", m.location);
        v.put("participants", m.participants);
        v.put("notes", m.notes);
        return v;
    }

    private Meeting fromCursor(Cursor c) {
        return new Meeting(
                c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("title")),
                c.getString(c.getColumnIndexOrThrow("date")),
                c.getString(c.getColumnIndexOrThrow("start_time")),
                c.getString(c.getColumnIndexOrThrow("end_time")),
                c.getString(c.getColumnIndexOrThrow("location")),
                c.getString(c.getColumnIndexOrThrow("participants")),
                c.getString(c.getColumnIndexOrThrow("notes")));
    }

    public long insert(Meeting m) {
        return getWritableDatabase().insert(TABLE, null, toValues(m));
    }

    public int update(Meeting m) {
        return getWritableDatabase().update(TABLE, toValues(m), "id = ?", new String[]{String.valueOf(m.id)});
    }

    public int delete(long id) {
        return getWritableDatabase().delete(TABLE, "id = ?", new String[]{String.valueOf(id)});
    }

    public Meeting getById(long id) {
        Cursor c = getReadableDatabase().query(TABLE, null, "id = ?", new String[]{String.valueOf(id)},
                null, null, null);
        try {
            return c.moveToFirst() ? fromCursor(c) : null;
        } finally {
            c.close();
        }
    }

    public List<Meeting> getAll() {
        List<Meeting> list = new ArrayList<>();
        Cursor c = getReadableDatabase().query(TABLE, null, null, null, null, null,
                "date ASC, start_time ASC");
        try {
            while (c.moveToNext()) list.add(fromCursor(c));
        } finally {
            c.close();
        }
        return list;
    }

    /**
     * True if another meeting in the same location (case-insensitive) on the same date overlaps
     * the given time range. Times are zero-padded HH:mm so string comparison is correct.
     * Pass excludeId = -1 when creating a new meeting.
     */
    public boolean hasConflict(String date, String location, String start, String end, long excludeId) {
        String sql = "SELECT COUNT(*) FROM " + TABLE
                + " WHERE date = ? AND LOWER(location) = LOWER(?)"
                + " AND start_time < ? AND end_time > ? AND id != ?";
        long n = DatabaseUtils.longForQuery(getReadableDatabase(), sql,
                new String[]{date, location, end, start, String.valueOf(excludeId)});
        return n > 0;
    }
}
