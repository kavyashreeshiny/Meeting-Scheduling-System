# Meeting Scheduling System (Android)

Android app to create, edit, delete and share meetings. Built for the Mobile Application Development (MAD) lab.

**Tools:** Java, Android SDK, SQLite, XML layouts

## Features
- Add meetings with title, date (DatePicker), start/end time (TimePicker), location, participants, notes
- Validation: required fields, end time after start time
- **Clash detection:** the same location cannot be double-booked for overlapping times
- List sorted by date and time; tap to edit, long-press to delete
- Share an invite through any app (WhatsApp, email, SMS) using an implicit Intent
- Local storage with SQLite (`SQLiteOpenHelper`), no third-party libraries

## Structure
| File | Role |
|---|---|
| `MainActivity` | Meeting list (ListView + custom adapter) |
| `AddEditMeetingActivity` | Create / edit / delete / share form |
| `DBHelper` | SQLite create, CRUD and conflict query |
| `MeetingAdapter`, `Meeting` | List rows and data model |

## Run
1. Open this folder in **Android Studio** (Hedgehog or newer), let Gradle sync.
2. If it asks about the Gradle wrapper or plugin version, accept the suggested versions.
3. Run on an emulator or a phone (Run > Run 'app'). Build > Build APK(s) for an installable file.

## Note
This project was written without access to the Android SDK, so it has not been compiled or run yet.
Open it in Android Studio, accept any Gradle/plugin version prompts, and test on an emulator before demoing.
